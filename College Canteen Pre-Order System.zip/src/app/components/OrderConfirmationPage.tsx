import { motion } from 'motion/react';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Paper from '@mui/material/Paper';
import Divider from '@mui/material/Divider';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import ConfirmationNumberIcon from '@mui/icons-material/ConfirmationNumber';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import { Order } from '../App';

interface OrderConfirmationPageProps {
  order: Order;
  onViewStatus: () => void;
  onBackToMenu: () => void;
}

export function OrderConfirmationPage({ order, onViewStatus, onBackToMenu }: OrderConfirmationPageProps) {
  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        display: 'flex',
        alignItems: 'center',
        py: 4,
      }}
    >
      <Container maxWidth="sm">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Paper
            elevation={6}
            sx={{
              borderRadius: 4,
              overflow: 'hidden',
            }}
          >
            {/* Success Header */}
            <Box
              sx={{
                bgcolor: 'success.main',
                color: 'white',
                textAlign: 'center',
                py: 4,
              }}
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
              >
                <CheckCircleIcon sx={{ fontSize: 80, mb: 2 }} />
              </motion.div>
              <Typography variant="h5" sx={{ fontWeight: 600 }}>
                Order Placed Successfully!
              </Typography>
            </Box>

            {/* Order Details */}
            <Box sx={{ p: 3 }}>
              <Box
                sx={{
                  bgcolor: 'primary.light',
                  borderRadius: 3,
                  p: 3,
                  mb: 3,
                  textAlign: 'center',
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1, mb: 1 }}>
                  <ConfirmationNumberIcon color="primary" />
                  <Typography variant="body2" color="primary.dark" sx={{ fontWeight: 600 }}>
                    Order Number
                  </Typography>
                </Box>
                <Typography variant="h3" color="primary.dark" sx={{ fontWeight: 700 }}>
                  {order.id}
                </Typography>
              </Box>

              <Paper
                elevation={0}
                sx={{
                  bgcolor: 'background.default',
                  borderRadius: 2,
                  p: 2.5,
                  mb: 3,
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
                  <AccessTimeIcon color="primary" />
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    Pickup Time
                  </Typography>
                </Box>
                <Typography variant="h5" color="primary.main" sx={{ fontWeight: 600 }}>
                  {order.pickupTime}
                </Typography>
              </Paper>

              {/* Order Items */}
              <Box sx={{ mb: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 1.5 }}>
                  Order Items
                </Typography>
                {order.items.map((item) => (
                  <Box
                    key={item.id}
                    sx={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      py: 1,
                    }}
                  >
                    <Typography color="text.secondary">
                      {item.name} × {item.quantity}
                    </Typography>
                    <Typography sx={{ fontWeight: 500 }}>
                      ₹{item.price * item.quantity}
                    </Typography>
                  </Box>
                ))}
                <Divider sx={{ my: 1.5 }} />
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    Total
                  </Typography>
                  <Typography variant="h6" color="primary.main" sx={{ fontWeight: 700 }}>
                    ₹{order.total.toFixed(2)}
                  </Typography>
                </Box>
              </Box>

              <Paper
                elevation={0}
                sx={{
                  bgcolor: 'success.light',
                  borderRadius: 2,
                  p: 2,
                  mb: 3,
                }}
              >
                <Box sx={{ display: 'flex', gap: 1.5 }}>
                  <RestaurantIcon sx={{ color: 'success.dark' }} />
                  <Box>
                    <Typography variant="body2" color="success.dark" sx={{ fontWeight: 600, mb: 0.5 }}>
                      Skip the Queue!
                    </Typography>
                    <Typography variant="body2" color="success.dark">
                      Show this order number at the pickup counter during your time slot. Your food will be ready!
                    </Typography>
                  </Box>
                </Box>
              </Paper>

              <Box sx={{ display: 'grid', gap: 1.5 }}>
                <Button
                  variant="contained"
                  size="large"
                  fullWidth
                  onClick={onViewStatus}
                  sx={{
                    textTransform: 'none',
                    fontWeight: 600,
                    py: 1.5,
                    borderRadius: 2,
                  }}
                >
                  Track Order Status
                </Button>
                <Button
                  variant="outlined"
                  size="large"
                  fullWidth
                  onClick={onBackToMenu}
                  sx={{
                    textTransform: 'none',
                    fontWeight: 600,
                    py: 1.5,
                    borderRadius: 2,
                  }}
                >
                  Back to Menu
                </Button>
              </Box>
            </Box>
          </Paper>
        </motion.div>
      </Container>
    </Box>
  );
}
