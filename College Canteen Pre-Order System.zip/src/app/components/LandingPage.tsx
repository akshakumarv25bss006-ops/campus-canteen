import { motion } from 'motion/react';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Paper from '@mui/material/Paper';
import FastfoodIcon from '@mui/icons-material/Fastfood';
import PersonIcon from '@mui/icons-material/Person';
import RestaurantIcon from '@mui/icons-material/Restaurant';

interface LandingPageProps {
  onGetStarted: () => void;
  onStaffAccess?: () => void;
}

export function LandingPage({ onGetStarted, onStaffAccess }: LandingPageProps) {
  return (
    <Box sx={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      display: 'flex',
      alignItems: 'center',
      py: 4,
    }}>
      <Container maxWidth="sm">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Box sx={{ textAlign: 'center', mb: 4 }}>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            >
              <Box
                sx={{
                  width: 100,
                  height: 100,
                  borderRadius: '50%',
                  bgcolor: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 24px',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
                }}
              >
                <FastfoodIcon sx={{ fontSize: 50, color: '#667eea' }} />
              </Box>
            </motion.div>

            <Typography 
              variant="h3" 
              sx={{ 
                color: 'white', 
                fontWeight: 700,
                mb: 2,
              }}
            >
              Campus Canteen
            </Typography>
            
            <Typography 
              variant="h5" 
              sx={{ 
                color: 'rgba(255,255,255,0.95)', 
                fontWeight: 400,
                mb: 1,
              }}
            >
              Skip the Queue. Pre-order your food.
            </Typography>

            <Typography 
              variant="body1" 
              sx={{ 
                color: 'rgba(255,255,255,0.85)', 
                mb: 5,
              }}
            >
              Queue-less food collection • Reduced waiting time
            </Typography>

            <Typography 
              variant="h6" 
              sx={{ 
                color: 'white', 
                fontWeight: 600,
                mb: 3,
              }}
            >
              Continue as
            </Typography>

            <Box sx={{ display: 'grid', gap: 2 }}>
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Paper
                  sx={{
                    p: 3,
                    borderRadius: 3,
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    '&:hover': {
                      transform: 'translateY(-4px)',
                      boxShadow: '0 12px 32px rgba(0,0,0,0.2)',
                    },
                  }}
                  onClick={onGetStarted}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <Box
                      sx={{
                        width: 60,
                        height: 60,
                        borderRadius: 2,
                        bgcolor: 'primary.light',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <PersonIcon sx={{ fontSize: 32, color: 'primary.main' }} />
                    </Box>
                    <Box sx={{ flex: 1, textAlign: 'left' }}>
                      <Typography variant="h6" sx={{ fontWeight: 600, mb: 0.5 }}>
                        🧑‍🎓 Student
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Browse menu & order food
                      </Typography>
                    </Box>
                  </Box>
                </Paper>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
              >
                <Paper
                  sx={{
                    p: 3,
                    borderRadius: 3,
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    bgcolor: '#1a237e',
                    color: 'white',
                    '&:hover': {
                      transform: 'translateY(-4px)',
                      boxShadow: '0 12px 32px rgba(0,0,0,0.3)',
                    },
                  }}
                  onClick={() => {
                    // Navigate to staff dashboard
                    if (onStaffAccess) {
                      onStaffAccess();
                    }
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <Box
                      sx={{
                        width: 60,
                        height: 60,
                        borderRadius: 2,
                        bgcolor: 'rgba(255,255,255,0.2)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <RestaurantIcon sx={{ fontSize: 32, color: 'white' }} />
                    </Box>
                    <Box sx={{ flex: 1, textAlign: 'left' }}>
                      <Typography variant="h6" sx={{ fontWeight: 600, mb: 0.5 }}>
                        🧑‍🍳 Canteen Staff
                      </Typography>
                      <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.8)' }}>
                        Manage incoming orders
                      </Typography>
                    </Box>
                  </Box>
                </Paper>
              </motion.div>
            </Box>
          </Box>
        </motion.div>
      </Container>
    </Box>
  );
}