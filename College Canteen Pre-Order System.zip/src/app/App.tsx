import { useState, useEffect } from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { LandingPage } from './components/LandingPage';
import { LoginPage } from './components/LoginPage';
import { MenuPage } from './components/MenuPage';
import { CartPage } from './components/CartPage';
import { OrderConfirmationPage } from './components/OrderConfirmationPage';
import { OrderStatusPage } from './components/OrderStatusPage';
import { StaffDashboard } from './components/StaffDashboard';

const theme = createTheme({
  palette: {
    primary: {
      main: '#5E92F3',
      light: '#A8C8F7',
      dark: '#3D6DB8',
    },
    secondary: {
      main: '#FF6B6B',
      light: '#FF9E9E',
      dark: '#E85555',
    },
    success: {
      main: '#51CF66',
      light: '#8CE99A',
      dark: '#37B24D',
    },
    background: {
      default: '#F8F9FA',
      paper: '#FFFFFF',
    },
    text: {
      primary: '#2D3436',
      secondary: '#636E72',
    },
  },
  shape: {
    borderRadius: 12,
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
  },
});

export type Page = 'landing' | 'login' | 'menu' | 'cart' | 'orderConfirmation' | 'orderStatus' | 'staffDashboard';

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  prepTime: number;
  available: boolean;
  isVeg: boolean;
}

export interface CartItem extends MenuItem {
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  pickupTime: string;
  status: 'pending' | 'preparing' | 'ready' | 'collected';
  timestamp: number;
  studentName: string;
  sentTime?: string;
}

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [allOrders, setAllOrders] = useState<Order[]>([]);
  const [studentName, setStudentName] = useState('');

  useEffect(() => {
    if (window.location.hash === '#staff') {
      setCurrentPage('staffDashboard');
    }
  }, []);

  const addToCart = (item: MenuItem) => {
    setCartItems((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) => 
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity === 0) {
      setCartItems((prev) => prev.filter((item) => item.id !== id));
    } else {
      setCartItems((prev) => 
        prev.map((item) => item.id === id ? { ...item, quantity } : item)
      );
    }
  };

  const placeOrder = (pickupTime: string) => {
    const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.05;
    const total = subtotal + tax;

    const now = new Date();
    const sentTime = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });

    const order: Order = {
      id: `ORD${Date.now().toString().slice(-6)}`,
      items: [...cartItems],
      total,
      pickupTime,
      status: 'pending',
      timestamp: Date.now(),
      studentName: studentName || 'Student',
      sentTime,
    };

    setCurrentOrder(order);
    setAllOrders((prev) => [...prev, order]);
    setCartItems([]);
    setCurrentPage('orderConfirmation');
  };

  const login = (name: string) => {
    setStudentName(name);
    setCurrentPage('menu');
  };

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    setAllOrders((prev) => 
      prev.map((order) => order.id === orderId ? { ...order, status } : order)
    );
    if (currentOrder?.id === orderId) {
      setCurrentOrder((prev) => prev ? { ...prev, status } : null);
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <div className="min-h-screen">
        {currentPage === 'landing' && (
          <LandingPage 
            onGetStarted={() => setCurrentPage('login')}
            onStaffAccess={() => setCurrentPage('staffDashboard')}
          />
        )}
        
        {currentPage === 'login' && (
          <LoginPage 
            onLogin={login}
            onStaffAccess={() => setCurrentPage('staffDashboard')}
          />
        )}
        
        {currentPage === 'menu' && (
          <MenuPage
            cartItemCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
            onAddToCart={addToCart}
            onViewCart={() => setCurrentPage('cart')}
            onViewOrders={() => setCurrentPage('orderStatus')}
          />
        )}
        
        {currentPage === 'cart' && (
          <CartPage
            items={cartItems}
            onUpdateQuantity={updateQuantity}
            onPlaceOrder={placeOrder}
            onBack={() => setCurrentPage('menu')}
          />
        )}
        
        {currentPage === 'orderConfirmation' && currentOrder && (
          <OrderConfirmationPage
            order={currentOrder}
            onViewStatus={() => setCurrentPage('orderStatus')}
            onBackToMenu={() => setCurrentPage('menu')}
          />
        )}
        
        {currentPage === 'orderStatus' && (
          <OrderStatusPage
            orders={allOrders.filter((o) => o.studentName === studentName)}
            onBack={() => setCurrentPage('menu')}
          />
        )}
        
        {currentPage === 'staffDashboard' && (
          <StaffDashboard
            orders={allOrders}
            onUpdateStatus={updateOrderStatus}
            onBack={() => setCurrentPage('landing')}
          />
        )}
      </div>
    </ThemeProvider>
  );
}

export default App;
