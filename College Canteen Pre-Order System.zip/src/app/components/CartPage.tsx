import { useState } from 'react';
import { motion } from 'motion/react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import Paper from '@mui/material/Paper';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import DeleteIcon from '@mui/icons-material/Delete';
import ShoppingCartCheckoutIcon from '@mui/icons-material/ShoppingCartCheckout';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { CartItem } from '../App';

interface CartPageProps {
  items: CartItem[];
  onUpdateQuantity: (id: string, quantity: number) => void;
  onPlaceOrder: (pickupTime: string) => void;
  onBack: () => void;
}

const TIME_SLOTS = [
  '10:00 AM - 10:30 AM',
  '11:00 AM - 11:30 AM',
  '12:00 PM - 12:30 PM',
  '1:00 PM - 1:30 PM',
  '2:00 PM - 2:30 PM',
  '3:00 PM - 3:30 PM',
  '4:00 PM - 4:30 PM',
];

export function CartPage({ items, onUpdateQuantity, onPlaceOrder, onBack }: CartPageProps) {
  const [selectedTime, setSelectedTime] = useState(TIME_SLOTS[0]);

  const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.05;
  const total = subtotal + tax;

  const handlePlaceOrder = () => {
    if (items.length > 0) {
      onPlaceOrder(selectedTime);
    }
  };

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default' }}>
      <AppBar position="sticky" elevation={1} sx={{ bgcolor: 'white', color: 'text.primary' }}>
        <Toolbar>
          <IconButton edge="start" onClick={onBack} sx={{ mr: 2 }}>
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
            Your Cart
          </Typography>
        </Toolbar>
      </AppBar>

      <Container maxWidth="md" sx={{ py: 3, pb: 12 }}>
        {items.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Paper sx={{ p: 6, textAlign: 'center', borderRadius: 3 }}>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                Your cart is empty
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Add some delicious items from the menu
              </Typography>
              <Button variant="contained" onClick={onBack} sx={{ textTransform: 'none' }}>
                Browse Menu
              </Button>
            </Paper>
          </motion.div>
        ) : (
          <>
            {/* Cart Items */}
            <Paper sx={{ borderRadius: 3, mb: 3, overflow: 'hidden' }}>
              <List sx={{ p: 0 }}>
                {items.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <ListItem
                      sx={{
                        flexDirection: 'column',
                        alignItems: 'stretch',
                        py: 2.5,
                        px: 2.5,
                        borderBottom: index < items.length - 1 ? '1px solid' : 'none',
                        borderColor: 'divider',
                      }}
                    >
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1.5 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box
                            sx={{
                              width: 14,
                              height: 14,
                              borderRadius: '50%',
                              border: '2px solid',
                              borderColor: item.isVeg ? 'success.main' : 'secondary.main',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              flexShrink: 0,
                            }}
                          >
                            <Box
                              sx={{
                                width: 6,
                                height: 6,
                                borderRadius: '50%',
                                bgcolor: item.isVeg ? 'success.main' : 'secondary.main',
                              }}
                            />
                          </Box>
                          <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
                            {item.name}
                          </Typography>
                        </Box>
                        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                          ₹{item.price * item.quantity}
                        </Typography>
                      </Box>

                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <IconButton
                            size="small"
                            onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                            sx={{
                              border: 1.5,
                              borderColor: 'primary.main',
                              color: 'primary.main',
                              width: 32,
                              height: 32,
                            }}
                          >
                            <RemoveIcon fontSize="small" />
                          </IconButton>
                          <Typography sx={{ minWidth: 36, textAlign: 'center', fontWeight: 600 }}>
                            {item.quantity}
                          </Typography>
                          <IconButton
                            size="small"
                            onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                            sx={{
                              border: 1.5,
                              borderColor: 'primary.main',
                              bgcolor: 'primary.main',
                              color: 'white',
                              width: 32,
                              height: 32,
                              '&:hover': {
                                bgcolor: 'primary.dark',
                              },
                            }}
                          >
                            <AddIcon fontSize="small" />
                          </IconButton>
                        </Box>

                        <IconButton
                          size="small"
                          onClick={() => onUpdateQuantity(item.id, 0)}
                          sx={{ color: 'secondary.main' }}
                        >
                          <DeleteIcon />
                        </IconButton>
                      </Box>
                    </ListItem>
                  </motion.div>
                ))}
              </List>
            </Paper>

            {/* Pickup Time Selection */}
            <Paper sx={{ borderRadius: 3, p: 3, mb: 3 }}>
              <FormControl fullWidth>
                <FormLabel sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                  <AccessTimeIcon color="primary" />
                  <Typography variant="h6" component="span" sx={{ fontWeight: 600 }}>
                    Select Pickup Time
                  </Typography>
                </FormLabel>
                <RadioGroup value={selectedTime} onChange={(e) => setSelectedTime(e.target.value)}>
                  <Box sx={{ display: 'grid', gap: 1 }}>
                    {TIME_SLOTS.map((slot) => (
                      <Paper
                        key={slot}
                        elevation={0}
                        sx={{
                          border: 1.5,
                          borderColor: selectedTime === slot ? 'primary.main' : 'divider',
                          borderRadius: 2,
                          bgcolor: selectedTime === slot ? 'primary.light' : 'transparent',
                          transition: 'all 0.2s',
                        }}
                      >
                        <FormControlLabel
                          value={slot}
                          control={<Radio />}
                          label={slot}
                          sx={{
                            m: 0,
                            p: 1.5,
                            width: '100%',
                            '& .MuiFormControlLabel-label': {
                              fontWeight: selectedTime === slot ? 600 : 400,
                            },
                          }}
                        />
                      </Paper>
                    ))}
                  </Box>
                </RadioGroup>
              </FormControl>
            </Paper>

            {/* Bill Summary */}
            <Paper sx={{ borderRadius: 3, p: 3, mb: 3 }}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                Bill Summary
              </Typography>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography color="text.secondary">Subtotal</Typography>
                <Typography>₹{subtotal.toFixed(2)}</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1.5 }}>
                <Typography color="text.secondary">Tax (5%)</Typography>
                <Typography>₹{tax.toFixed(2)}</Typography>
              </Box>
              <Divider sx={{ my: 1.5 }} />
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Total
                </Typography>
                <Typography variant="h6" color="primary.main" sx={{ fontWeight: 700 }}>
                  ₹{total.toFixed(2)}
                </Typography>
              </Box>
            </Paper>
          </>
        )}
      </Container>

      {/* Fixed Bottom Button */}
      {items.length > 0 && (
        <Paper
          elevation={8}
          sx={{
            position: 'fixed',
            bottom: 0,
            left: 0,
            right: 0,
            p: 2,
            borderRadius: 0,
          }}
        >
          <Container maxWidth="md">
            <Button
              variant="contained"
              size="large"
              fullWidth
              startIcon={<ShoppingCartCheckoutIcon />}
              onClick={handlePlaceOrder}
              sx={{
                py: 1.5,
                fontSize: '1rem',
                fontWeight: 600,
                textTransform: 'none',
                borderRadius: 3,
                boxShadow: '0 4px 16px rgba(94, 146, 243, 0.3)',
              }}
            >
              Place Order • ₹{total.toFixed(2)}
            </Button>
          </Container>
        </Paper>
      )}
    </Box>
  );
}
