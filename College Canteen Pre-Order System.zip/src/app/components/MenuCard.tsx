import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Chip from '@mui/material/Chip';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import AddIcon from '@mui/icons-material/Add';
import { MenuItem } from '../App';

interface MenuCardProps {
  item: MenuItem;
  onAddToCart: (item: MenuItem) => void;
}

export function MenuCard({ item, onAddToCart }: MenuCardProps) {
  return (
    <Card 
      sx={{ 
        display: 'flex', 
        borderRadius: 3,
        overflow: 'hidden',
        transition: 'transform 0.2s, box-shadow 0.2s',
        '&:hover': {
          transform: 'translateY(-2px)',
          boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
        },
      }}
    >
      <CardMedia
        component="img"
        sx={{ width: 120, objectFit: 'cover' }}
        image={item.image}
        alt={item.name}
      />
      <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
        <CardContent sx={{ flex: '1 0 auto', pb: 1, pt: 1.5, px: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1, mb: 0.5 }}>
            <Typography component="div" variant="h6" sx={{ flex: 1, fontSize: '1rem' }}>
              {item.name}
            </Typography>
            <Box
              sx={{
                width: 16,
                height: 16,
                borderRadius: '50%',
                border: '2px solid',
                borderColor: item.isVeg ? 'success.main' : 'secondary.main',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              <Box
                sx={{
                  width: 8,
                  height: 8,
                  borderRadius: '50%',
                  bgcolor: item.isVeg ? 'success.main' : 'secondary.main',
                }}
              />
            </Box>
          </Box>
          
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5, fontSize: '0.875rem' }}>
            {item.description}
          </Typography>
          
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <Typography variant="h6" color="primary.main" sx={{ fontWeight: 600 }}>
              ₹{item.price}
            </Typography>
            <Chip 
              icon={<AccessTimeIcon sx={{ fontSize: 16 }} />} 
              label={`${item.prepTime} min`} 
              size="small"
              sx={{ 
                height: 24,
                fontSize: '0.75rem',
                bgcolor: 'primary.light',
                color: 'primary.dark',
                '& .MuiChip-icon': { color: 'primary.dark' },
              }}
            />
          </Box>
        </CardContent>
        
        <Box sx={{ px: 2, pb: 1.5 }}>
          <Button
            variant="contained"
            size="small"
            startIcon={<AddIcon />}
            onClick={() => onAddToCart(item)}
            fullWidth
            disabled={!item.available}
            sx={{
              textTransform: 'none',
              fontWeight: 600,
              borderRadius: 2,
              boxShadow: 'none',
              '&:hover': {
                boxShadow: '0 2px 8px rgba(94, 146, 243, 0.3)',
              },
            }}
          >
            Add to Cart
          </Button>
        </Box>
      </Box>
    </Card>
  );
}
