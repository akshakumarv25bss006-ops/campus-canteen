import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Button from '@mui/material/Button';
import Chip from '@mui/material/Chip';
import Badge from '@mui/material/Badge';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SupervisorAccountIcon from '@mui/icons-material/SupervisorAccount';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import { Order } from '../App';

interface StaffDashboardProps {
  orders: Order[];
  onUpdateStatus: (orderId: string, status: Order['status']) => void;
  onBack: () => void;
}

const STATUS_COLORS = {
  pending: 'info',
  preparing: 'warning',
  ready: 'success',
  collected: 'default',
};

const STATUS_LABELS = {
  pending: 'New Order',
  preparing: 'Preparing',
  ready: 'Ready',
  collected: 'Collected',
};

export function StaffDashboard({ orders, onUpdateStatus, onBack }: StaffDashboardProps) {
  const [seenOrders, setSeenOrders] = useState<Set<string>>(new Set());
  const [highlightedOrder, setHighlightedOrder] = useState<string | null>(null);

  const sortedOrders = [...orders].sort((a, b) => b.timestamp - a.timestamp);
  const newOrders = orders.filter(o => o.status === 'pending');

  // Detect new orders and highlight them
  useEffect(() => {
    orders.forEach(order => {
      if (order.status === 'pending' && !seenOrders.has(order.id)) {
        setHighlightedOrder(order.id);
        setTimeout(() => setHighlightedOrder(null), 3000);
      }
    });
  }, [orders, seenOrders]);

  const handleAcceptOrder = (orderId: string) => {
    onUpdateStatus(orderId, 'preparing');
    setSeenOrders(prev => new Set(prev).add(orderId));
  };

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default' }}>
      <AppBar position="sticky" elevation={2} sx={{ bgcolor: '#1a237e' }}>
        <Toolbar>
          <IconButton edge="start" onClick={onBack} sx={{ mr: 2, color: 'white' }}>
            <ArrowBackIcon />
          </IconButton>
          <SupervisorAccountIcon sx={{ mr: 1.5, color: 'white' }} />
          <Typography variant="h6" component="div" sx={{ fontWeight: 600, color: 'white', flexGrow: 1 }}>
            Canteen Staff Dashboard
          </Typography>
          <Badge badgeContent={newOrders.length} color="error" sx={{ mr: 2 }}>
            <NotificationsActiveIcon sx={{ color: 'white' }} />
          </Badge>
          <Chip
            label={`${orders.filter(o => o.status !== 'collected').length} Active`}
            sx={{ 
              bgcolor: 'warning.main',
              color: 'warning.contrastText',
              fontWeight: 600,
            }}
          />
        </Toolbar>
      </AppBar>

      <Container maxWidth="xl" sx={{ py: 3 }}>
        {/* Live Orders Header */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
          <Typography variant="h5" sx={{ fontWeight: 700 }}>
            🔔 Live Orders Panel
          </Typography>
          {newOrders.length > 0 && (
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            >
              <Chip
                label={`${newOrders.length} New Order${newOrders.length > 1 ? 's' : ''}`}
                color="error"
                sx={{ fontWeight: 600 }}
              />
            </motion.div>
          )}
        </Box>

        {orders.length === 0 ? (
          <Paper sx={{ p: 6, textAlign: 'center', borderRadius: 3 }}>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No orders yet
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Orders will appear here as customers place them
            </Typography>
          </Paper>
        ) : (
          <AnimatePresence mode="popLayout">
            <TableContainer component={Paper} sx={{ borderRadius: 3, boxShadow: 3 }}>
              <Table>
                <TableHead>
                  <TableRow sx={{ bgcolor: 'primary.light' }}>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Order ID</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Customer</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Items</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Quantity</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Pickup Time</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Total</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Status</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.95rem' }}>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {sortedOrders.map((order, index) => {
                    const isHighlighted = highlightedOrder === order.id;
                    const isNew = order.status === 'pending';
                    
                    return (
                      <motion.tr
                        key={order.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ 
                          opacity: 1, 
                          x: 0,
                          backgroundColor: isHighlighted 
                            ? '#FFE0E0' 
                            : isNew 
                            ? '#FFF4E5' 
                            : order.status === 'ready' 
                            ? '#E8F5E9' 
                            : 'transparent'
                        }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ delay: index * 0.05 }}
                        component={TableRow}
                        sx={{
                          '&:hover': { bgcolor: 'action.hover' },
                          position: 'relative',
                        }}
                      >
                        {isNew && (
                          <motion.div
                            initial={{ opacity: 0, scale: 0 }}
                            animate={{ opacity: 1, scale: 1 }}
                            style={{
                              position: 'absolute',
                              top: 8,
                              left: 8,
                              width: 12,
                              height: 12,
                              borderRadius: '50%',
                              backgroundColor: '#f44336',
                            }}
                          />
                        )}
                        
                        <TableCell>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            {isNew && (
                              <Chip 
                                label="NEW" 
                                size="small" 
                                color="error"
                                sx={{ fontSize: '0.7rem', height: 20 }}
                              />
                            )}
                            <Typography variant="body2" sx={{ fontWeight: 700, fontFamily: 'monospace' }}>
                              {order.id}
                            </Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 500 }}>
                            {order.studentName}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Box>
                            {order.items.map((item, i) => (
                              <Typography key={i} variant="body2" sx={{ fontSize: '0.85rem' }}>
                                {item.name}
                              </Typography>
                            ))}
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Box>
                            {order.items.map((item, i) => (
                              <Typography key={i} variant="body2" sx={{ fontSize: '0.85rem' }}>
                                × {item.quantity}
                              </Typography>
                            ))}
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 500 }}>
                            {order.pickupTime}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 600, color: 'primary.main' }}>
                            ₹{order.total.toFixed(2)}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={STATUS_LABELS[order.status]}
                            color={STATUS_COLORS[order.status] as any}
                            size="small"
                            sx={{ fontWeight: 600, minWidth: 90 }}
                          />
                        </TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                            {order.status === 'pending' && (
                              <motion.div
                                animate={{ scale: [1, 1.05, 1] }}
                                transition={{ repeat: Infinity, duration: 1.5 }}
                              >
                                <Button
                                  size="small"
                                  variant="contained"
                                  color="primary"
                                  onClick={() => handleAcceptOrder(order.id)}
                                  sx={{ 
                                    textTransform: 'none', 
                                    fontSize: '0.8rem',
                                    fontWeight: 700,
                                    boxShadow: 3,
                                  }}
                                >
                                  Accept Order
                                </Button>
                              </motion.div>
                            )}
                            {order.status === 'preparing' && (
                              <Button
                                size="small"
                                variant="contained"
                                color="success"
                                onClick={() => onUpdateStatus(order.id, 'ready')}
                                sx={{ textTransform: 'none', fontSize: '0.8rem', fontWeight: 600 }}
                              >
                                Mark Ready
                              </Button>
                            )}
                            {order.status === 'ready' && (
                              <Button
                                size="small"
                                variant="outlined"
                                onClick={() => onUpdateStatus(order.id, 'collected')}
                                sx={{ textTransform: 'none', fontSize: '0.8rem' }}
                              >
                                Collected
                              </Button>
                            )}
                            {order.status === 'collected' && (
                              <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.8rem', py: 0.5 }}>
                                ✅ Completed
                              </Typography>
                            )}
                          </Box>
                        </TableCell>
                      </motion.tr>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </AnimatePresence>
        )}

        {/* Summary Stats */}
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 2, mt: 3 }}>
          <Paper sx={{ p: 2.5, borderRadius: 3, bgcolor: 'info.light' }}>
            <Typography variant="body2" color="info.dark" sx={{ mb: 0.5 }}>
              New Orders
            </Typography>
            <Typography variant="h4" color="info.dark" sx={{ fontWeight: 700 }}>
              {orders.filter(o => o.status === 'pending').length}
            </Typography>
          </Paper>
          
          <Paper sx={{ p: 2.5, borderRadius: 3, bgcolor: 'warning.light' }}>
            <Typography variant="body2" color="warning.dark" sx={{ mb: 0.5 }}>
              Preparing
            </Typography>
            <Typography variant="h4" color="warning.dark" sx={{ fontWeight: 700 }}>
              {orders.filter(o => o.status === 'preparing').length}
            </Typography>
          </Paper>
          
          <Paper sx={{ p: 2.5, borderRadius: 3, bgcolor: 'success.light' }}>
            <Typography variant="body2" color="success.dark" sx={{ mb: 0.5 }}>
              Ready
            </Typography>
            <Typography variant="h4" color="success.dark" sx={{ fontWeight: 700 }}>
              {orders.filter(o => o.status === 'ready').length}
            </Typography>
          </Paper>
          
          <Paper sx={{ p: 2.5, borderRadius: 3, bgcolor: 'grey.200' }}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
              Completed Today
            </Typography>
            <Typography variant="h4" color="text.primary" sx={{ fontWeight: 700 }}>
              {orders.filter(o => o.status === 'collected').length}
            </Typography>
          </Paper>
        </Box>
      </Container>
    </Box>
  );
}
