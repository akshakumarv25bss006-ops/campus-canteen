import { motion } from 'motion/react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Chip from '@mui/material/Chip';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import RestaurantMenuIcon from '@mui/icons-material/RestaurantMenu';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import SendIcon from '@mui/icons-material/Send';
import { Order } from '../App';

interface OrderStatusPageProps {
  orders: Order[];
  onBack: () => void;
}

const STATUS_CONFIG = {
  pending: { step: 0, label: 'Sent to Canteen', color: 'info', icon: '✔️' },
  preparing: { step: 1, label: 'Preparing', color: 'warning', icon: '🍳' },
  ready: { step: 2, label: 'Ready for Pickup', color: 'success', icon: '🔔' },
  collected: { step: 3, label: 'Collected', color: 'default', icon: '🎉' },
};

export function OrderStatusPage({ orders, onBack }: OrderStatusPageProps) {
  const activeOrders = orders.filter(o => o.status !== 'collected');
  const pastOrders = orders.filter(o => o.status === 'collected');

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default' }}>
      <AppBar position="sticky" elevation={1} sx={{ bgcolor: 'white', color: 'text.primary' }}>
        <Toolbar>
          <IconButton edge="start" onClick={onBack} sx={{ mr: 2 }}>
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
            My Orders
          </Typography>
        </Toolbar>
      </AppBar>

      <Container maxWidth="md" sx={{ py: 3 }}>
        {orders.length === 0 ? (
          <Paper sx={{ p: 6, textAlign: 'center', borderRadius: 3 }}>
            <RestaurantMenuIcon sx={{ fontSize: 60, color: 'text.secondary', mb: 2 }} />
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No orders yet
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Place your first order to see it here
            </Typography>
          </Paper>
        ) : (
          <>
            {/* Active Orders */}
            {activeOrders.length > 0 && (
              <Box sx={{ mb: 4 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2, px: 1 }}>
                  Active Orders
                </Typography>
                {activeOrders.map((order, index) => (
                  <motion.div
                    key={order.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <OrderCard order={order} />
                  </motion.div>
                ))}
              </Box>
            )}

            {/* Past Orders */}
            {pastOrders.length > 0 && (
              <Box>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2, px: 1 }}>
                  Past Orders
                </Typography>
                {pastOrders.map((order, index) => (
                  <motion.div
                    key={order.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <OrderCard order={order} />
                  </motion.div>
                ))}
              </Box>
            )}
          </>
        )}
      </Container>
    </Box>
  );
}

function OrderCard({ order }: { order: Order }) {
  const config = STATUS_CONFIG[order.status];
  
  return (
    <Paper
      sx={{
        borderRadius: 3,
        overflow: 'hidden',
        mb: 2.5,
        border: 2,
        borderColor: order.status === 'ready' ? 'success.main' : order.status === 'pending' ? 'info.main' : 'divider',
      }}
    >
      {/* Header */}
      <Box
        sx={{
          bgcolor: order.status === 'ready' ? 'success.light' : order.status === 'pending' ? 'info.light' : 'primary.light',
          p: 2,
        }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
          <Box>
            <Typography variant="subtitle2" sx={{ fontSize: '0.75rem', opacity: 0.8 }}>
              Order ID
            </Typography>
            <Typography variant="h6" sx={{ fontWeight: 700, fontFamily: 'monospace' }}>
              {order.id}
            </Typography>
          </Box>
          <Chip
            label={`${config.icon} ${config.label}`}
            color={config.color as any}
            sx={{ fontWeight: 600, fontSize: '0.875rem' }}
          />
        </Box>

        {/* Important Timestamp */}
        {order.sentTime && order.status === 'pending' && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Paper
              elevation={0}
              sx={{
                bgcolor: 'rgba(255,255,255,0.9)',
                p: 1.5,
                borderRadius: 2,
                display: 'flex',
                alignItems: 'center',
                gap: 1,
              }}
            >
              <SendIcon sx={{ fontSize: 20, color: 'info.dark' }} />
              <Typography variant="body2" sx={{ fontWeight: 600, color: 'info.dark' }}>
                Order sent to canteen at {order.sentTime}
              </Typography>
            </Paper>
          </motion.div>
        )}
      </Box>

      {/* Order Details */}
      <Box sx={{ p: 2.5 }}>
        {/* Status Stepper */}
        <Stepper activeStep={config.step} alternativeLabel sx={{ mb: 3 }}>
          <Step>
            <StepLabel>Sent</StepLabel>
          </Step>
          <Step>
            <StepLabel>Preparing</StepLabel>
          </Step>
          <Step>
            <StepLabel>Ready</StepLabel>
          </Step>
          <Step>
            <StepLabel>Collected</StepLabel>
          </Step>
        </Stepper>

        {/* Pickup Time */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            mb: 2.5,
            p: 1.5,
            bgcolor: 'background.default',
            borderRadius: 2,
          }}
        >
          <AccessTimeIcon color="primary" fontSize="small" />
          <Typography variant="body2" color="text.secondary">
            Pickup Time:
          </Typography>
          <Typography variant="body2" sx={{ fontWeight: 600 }}>
            {order.pickupTime}
          </Typography>
        </Box>

        {/* Items */}
        <Box>
          <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
            Items Ordered
          </Typography>
          {order.items.map((item) => (
            <Box
              key={item.id}
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                py: 0.75,
              }}
            >
              <Typography variant="body2">
                {item.name} × {item.quantity}
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 500 }}>
                ₹{item.price * item.quantity}
              </Typography>
            </Box>
          ))}
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              pt: 1.5,
              mt: 1.5,
              borderTop: 1,
              borderColor: 'divider',
            }}
          >
            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
              Total
            </Typography>
            <Typography variant="subtitle2" color="primary" sx={{ fontWeight: 700 }}>
              ₹{order.total.toFixed(2)}
            </Typography>
          </Box>
        </Box>

        {/* Ready Alert */}
        {order.status === 'ready' && (
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Paper
              elevation={0}
              sx={{
                bgcolor: 'success.light',
                p: 2.5,
                borderRadius: 2,
                mt: 2,
                border: 2,
                borderColor: 'success.main',
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5 }}>
                <CheckCircleIcon sx={{ color: 'success.dark', fontSize: 28 }} />
                <Typography variant="h6" color="success.dark" sx={{ fontWeight: 700 }}>
                  Your order is ready!
                </Typography>
              </Box>
              <Typography variant="body2" color="success.dark" sx={{ ml: 5 }}>
                Please collect from the counter. Show order ID: <strong>{order.id}</strong>
              </Typography>
            </Paper>
          </motion.div>
        )}
      </Box>
    </Paper>
  );
}
