import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Badge from '@mui/material/Badge';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Chip from '@mui/material/Chip';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import ReceiptIcon from '@mui/icons-material/Receipt';
import { MenuCard } from './MenuCard';
import { MenuItem } from '../App';

const MENU_ITEMS: MenuItem[] = [
  {
    id: '1',
    name: 'Paneer Tikka Wrap',
    description: 'Grilled cottage cheese with spices in a soft wrap',
    price: 120,
    category: 'Main Course',
    image: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=400',
    prepTime: 15,
    available: true,
    isVeg: true,
  },
  {
    id: '2',
    name: 'Chicken Burger',
    description: 'Juicy grilled chicken patty with fresh veggies',
    price: 150,
    category: 'Main Course',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400',
    prepTime: 18,
    available: true,
    isVeg: false,
  },
  {
    id: '3',
    name: 'Margherita Pizza',
    description: 'Classic pizza with mozzarella and basil',
    price: 180,
    category: 'Main Course',
    image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400',
    prepTime: 20,
    available: true,
    isVeg: true,
  },
  {
    id: '4',
    name: 'Masala Dosa',
    description: 'Crispy dosa with spiced potato filling',
    price: 80,
    category: 'South Indian',
    image: 'https://images.unsplash.com/photo-1630383249896-424e482df921?w=400',
    prepTime: 15,
    available: true,
    isVeg: true,
  },
  {
    id: '5',
    name: 'Veg Fried Rice',
    description: 'Indo-Chinese style fried rice with vegetables',
    price: 100,
    category: 'Rice & Noodles',
    image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400',
    prepTime: 12,
    available: true,
    isVeg: true,
  },
  {
    id: '6',
    name: 'Egg Noodles',
    description: 'Stir-fried noodles with scrambled eggs',
    price: 110,
    category: 'Rice & Noodles',
    image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=400',
    prepTime: 12,
    available: true,
    isVeg: false,
  },
  {
    id: '7',
    name: 'Samosa (2 pcs)',
    description: 'Crispy pastry filled with spiced potatoes',
    price: 40,
    category: 'Snacks',
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400',
    prepTime: 8,
    available: true,
    isVeg: true,
  },
  {
    id: '8',
    name: 'Veg Sandwich',
    description: 'Grilled sandwich with cucumber and tomato',
    price: 60,
    category: 'Snacks',
    image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=400',
    prepTime: 10,
    available: true,
    isVeg: true,
  },
  {
    id: '9',
    name: 'Cold Coffee',
    description: 'Chilled coffee with ice cream',
    price: 70,
    category: 'Beverages',
    image: 'https://images.unsplash.com/photo-1517487881594-2787fef5ebf7?w=400',
    prepTime: 5,
    available: true,
    isVeg: true,
  },
  {
    id: '10',
    name: 'Mango Lassi',
    description: 'Sweet yogurt drink with mango pulp',
    price: 60,
    category: 'Beverages',
    image: 'https://images.unsplash.com/photo-1505252585461-04db1eb84625?w=400',
    prepTime: 5,
    available: true,
    isVeg: true,
  },
];

const CATEGORIES = ['All', 'Main Course', 'South Indian', 'Rice & Noodles', 'Snacks', 'Beverages'];

interface MenuPageProps {
  cartItemCount: number;
  onAddToCart: (item: MenuItem) => void;
  onViewCart: () => void;
  onViewOrders: () => void;
}

export function MenuPage({ cartItemCount, onAddToCart, onViewCart, onViewOrders }: MenuPageProps) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [vegFilter, setVegFilter] = useState<'all' | 'veg' | 'nonveg'>('all');

  const filteredItems = MENU_ITEMS.filter(item => {
    const categoryMatch = selectedCategory === 'All' || item.category === selectedCategory;
    const vegMatch = vegFilter === 'all' || 
      (vegFilter === 'veg' && item.isVeg) || 
      (vegFilter === 'nonveg' && !item.isVeg);
    return categoryMatch && vegMatch;
  });

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default', pb: 2 }}>
      <AppBar position="sticky" elevation={1} sx={{ bgcolor: 'white', color: 'text.primary' }}>
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1, fontWeight: 600 }}>
            Menu
          </Typography>
          <IconButton onClick={onViewOrders} sx={{ mr: 1 }}>
            <ReceiptIcon />
          </IconButton>
          <IconButton onClick={onViewCart}>
            <Badge badgeContent={cartItemCount} color="secondary">
              <ShoppingCartIcon />
            </Badge>
          </IconButton>
        </Toolbar>
      </AppBar>

      <Container maxWidth="md" sx={{ mt: 2 }}>
        {/* Veg Filter */}
        <Box sx={{ display: 'flex', gap: 1, mb: 2, px: 1 }}>
          <Chip
            label="All"
            onClick={() => setVegFilter('all')}
            color={vegFilter === 'all' ? 'primary' : 'default'}
            sx={{ borderRadius: 2 }}
          />
          <Chip
            label="🟢 Veg"
            onClick={() => setVegFilter('veg')}
            color={vegFilter === 'veg' ? 'success' : 'default'}
            sx={{ borderRadius: 2 }}
          />
          <Chip
            label="🔴 Non-Veg"
            onClick={() => setVegFilter('nonveg')}
            color={vegFilter === 'nonveg' ? 'secondary' : 'default'}
            sx={{ borderRadius: 2 }}
          />
        </Box>

        {/* Category Tabs */}
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
          <Tabs
            value={selectedCategory}
            onChange={(_, newValue) => setSelectedCategory(newValue)}
            variant="scrollable"
            scrollButtons="auto"
            sx={{
              '& .MuiTab-root': {
                textTransform: 'none',
                fontWeight: 500,
              },
            }}
          >
            {CATEGORIES.map(category => (
              <Tab key={category} label={category} value={category} />
            ))}
          </Tabs>
        </Box>

        {/* Menu Items */}
        <Box sx={{ display: 'grid', gap: 2 }}>
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: index * 0.05 }}
              >
                <MenuCard item={item} onAddToCart={onAddToCart} />
              </motion.div>
            ))}
          </AnimatePresence>
        </Box>

        {filteredItems.length === 0 && (
          <Box sx={{ textAlign: 'center', py: 8 }}>
            <Typography color="text.secondary">
              No items found in this category
            </Typography>
          </Box>
        )}
      </Container>
    </Box>
  );
}
